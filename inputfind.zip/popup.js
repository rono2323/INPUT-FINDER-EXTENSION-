document.addEventListener('DOMContentLoaded', () => {
  const findInputsBtn = document.getElementById('findInputs');
  const highlightInputsBtn = document.getElementById('highlightInputs');
  const testTextInputsBtn = document.getElementById('testTextInputs');
  const testTextInput = document.getElementById('testText');
  const resultsDiv = document.getElementById('results');

  // Get active tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const currentTab = tabs[0];
    
    // Find inputs button
    findInputsBtn.addEventListener('click', () => {
      chrome.scripting.executeScript({
        target: { tabId: currentTab.id },
        func: findInputElements,
      }, (results) => {
        displayResults(results[0].result);
      });
    });

    // Highlight inputs button
    highlightInputsBtn.addEventListener('click', () => {
      chrome.tabs.sendMessage(currentTab.id, { action: 'highlight' }, (response) => {
        updateStatus(`Highlighted ${response?.count || 0} inputs`);
      });
    });

    // Test text in inputs button
    testTextInputsBtn.addEventListener('click', () => {
      const testText = testTextInput.value || 'test';
      chrome.tabs.sendMessage(currentTab.id, { 
        action: 'enterText',
        text: testText,
        submit: true
      }, (response) => {
        updateStatus(`Entered text in ${response?.count || 0} inputs`);
      });
    });
  });

  // Function to find input elements
  function findInputElements() {
    const inputs = Array.from(document.querySelectorAll(
      'input, textarea, select, [contenteditable="true"], [role="textbox"]'
    ));
    
    return inputs.map(input => ({
      tagName: input.tagName,
      id: input.id || '',
      name: input.name || '',
      type: input.type || '',
      placeholder: input.placeholder || '',
      value: input.value || '',
      outerHTML: input.outerHTML.substring(0, 150) + 
                (input.outerHTML.length > 150 ? '...' : '')
    }));
  }

  // Display results
  function displayResults(inputs) {
    resultsDiv.innerHTML = '';
    
    if (!inputs || inputs.length === 0) {
      resultsDiv.innerHTML = '<div class="input-item">No input elements found.</div>';
      return;
    }
    
    inputs.forEach(input => {
      const item = document.createElement('div');
      item.className = 'input-item';
      
      let info = `<strong>${input.tagName}</strong>`;
      if (input.id) info += ` | ID: ${input.id}`;
      if (input.name) info += ` | Name: ${input.name}`;
      if (input.type) info += ` | Type: ${input.type}`;
      if (input.value) info += ` | Value: ${input.value.substring(0, 30)}${input.value.length > 30 ? '...' : ''}`;
      
      item.innerHTML = `
        <div>${info}</div>
        <small>${input.outerHTML}</small>
        <div class="input-actions">
          <button data-type="fill" data-id="${input.id}">Fill Text</button>
          <button data-type="search" data-id="${input.id}">Test Search</button>
        </div>
      `;
      resultsDiv.appendChild(item);
    });

    // Add event listeners to action buttons
    document.querySelectorAll('.input-actions button').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const action = e.target.getAttribute('data-type');
        const inputId = e.target.getAttribute('data-id');
        const testText = testTextInput.value || 'test';
        
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            func: performInputAction,
            args: [inputId, testText, action]
          });
        });
      });
    });
  }

  // Update status
  function updateStatus(message) {
    const status = document.createElement('div');
    status.textContent = message;
    status.style.marginTop = '10px';
    status.style.color = '#4285f4';
    resultsDiv.appendChild(status);
    setTimeout(() => status.remove(), 3000);
  }
});

// Function to perform actions on specific inputs
function performInputAction(inputId, text, action) {
  let input;
  if (inputId) {
    input = document.getElementById(inputId);
  } else {
    // Fallback to first input if no ID
    const inputs = document.querySelectorAll('input, textarea');
    if (inputs.length > 0) input = inputs[0];
  }

  if (input) {
    if (input.type === 'text' || input.type === 'search' || input.tagName === 'TEXTAREA') {
      input.value = text;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      
      if (action === 'search') {
        if (input.form) {
          input.form.dispatchEvent(new Event('submit', { cancelable: true }));
        } else {
          input.dispatchEvent(new KeyboardEvent('keydown', { 
            key: 'Enter', 
            code: 'Enter', 
            keyCode: 13, 
            bubbles: true 
          }));
        }
      }
    } else if (input.isContentEditable) {
      input.textContent = text;
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }
}
