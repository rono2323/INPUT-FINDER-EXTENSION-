// Function to highlight inputs
function highlightInputs() {
  const inputs = document.querySelectorAll('input, textarea, [contenteditable="true"]');
  inputs.forEach(input => {
    input.style.outline = '2px solid #4285f4';
    input.style.outlineOffset = '2px';
  });
  return inputs.length;
}

// Function to enter test text and optionally submit
function enterTestText(text, submit = false) {
  const inputs = document.querySelectorAll('input[type="text"], input[type="search"], textarea, [contenteditable="true"]');
  
  inputs.forEach(input => {
    if (input.type === 'text' || input.type === 'search' || input.tagName === 'TEXTAREA') {
      input.value = text;
      // Trigger change events
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      
      if (submit) {
        // Try to find associated form or simulate Enter key
        if (input.form) {
          input.form.dispatchEvent(new Event('submit', { cancelable: true }));
        } else {
          input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
        }
      }
    } else if (input.isContentEditable) {
      input.textContent = text;
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }
  });
  
  return inputs.length;
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'highlight') {
    const count = highlightInputs();
    sendResponse({ count });
  } else if (request.action === 'enterText') {
    const count = enterTestText(request.text, request.submit);
    sendResponse({ count });
  }
});
